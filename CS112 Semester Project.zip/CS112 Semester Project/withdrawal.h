class withdrawal: public course
{
    private:
    string num;
    string Course;
    public:
    
    void withdrawalcourse()//function of withdrawal of courses
    {
        
        cout<<"Enter the name of the course you want to withdraw ";
        cin>>num;
        
        if(num=="HM102")//checking the right string
        {
            
        for(int j=0;j<sub.size();j++)
        {
            if(sub.at(j)=="HM102")
        {
            //cout<<"IN process ";
            sub.at(j)=" ";
            
        }
           
        }
        }
        else if(num=="ES111")//checking the right string
        {
            for(int j=0;j<sub.size();j++)
        {

        
        if(sub.at(j)=="ES111")//checking the right string
        {
            sub.at(j)=" ";
        }

        }
        }
        else if(num=="CE121")//checking the right string
        {
            for(int j=0;j<sub.size();j++)
        {
         if(sub.at(j)=="CE121")
        {
            sub.at(j)=" ";
        }
        }
        }
        else if(num=="CS112")//checking the right string
        {
            for(int j=0;j<sub.size();j++)
        {
            if(sub.at(j)=="CS112")
        {
            sub.at(j)=" ";
        }
        }
        }
        else if(num=="CS131") //checking the right string
        {
            for(int j=0;j<sub.size();j++)
        {
            if(sub.at(j)=="CS131")
        {
            sub.at(j)=" ";
        }
        }
        }
        else if(num=="CE121L")//checking the right string
        {
            for(int j=0;j<sub.size();j++)
        {
            if(sub.at(j)=="CE121L")
        {
            sub.at(j)=" ";
        }
        }
        }
        else if (num=="CS112L")//checking the right string
        {
            for(int j=0;j<sub.size();j++)
        {
            if(sub.at(j)=="CS112L")
        {
            sub.at(j)=" ";
        }
        }
        }
        else 
        {
        cout<<"There is no such course you have opted "<<endl;
        }
          
         
            
}
        
    virtual void display()
        {
            
            cout<<"Your courses after withdrawal are "<<endl;
            //cout<<"Displaying "<<endl;
            for(int k=0;k<sub.size();k++)
        {
            fstream file;
            remove("CMS.csv");//removing old file
            file.close();
            //fstream file;
            file.open("CMSnew.csv",ios::out|ios::app);//opening file
            file<<sub.at(k)<<endl;//adding new data in file
            file.close();//closing fuke
            cout<<k<<"  "<<sub.at(k)<<endl;//displaying file
        }
        
        }
    
};
