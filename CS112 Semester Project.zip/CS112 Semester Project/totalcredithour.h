class Totalcredithours:public course 
{
    private:
    int credit=0;
    public:
     Totalcredithours()
     {
         credit=0;//initilizing in constructors
     }
    void totalcredithrs()
    {
        
        
       // cout << sub.size() << endl;

        for(int num2=0;num2<sub.size();num2++)//size of array
        {
            
        if(sub.at(num2)=="HM102")
        {
            
            credit=credit+3;//adding credit hours
            
        }
        
        else if(sub.at(num2)=="ES111")
        {
            
            credit=credit+3;//adding credit hours
        }
        
        
        else if(sub.at(num2)=="CE121")
        {
            
            credit=credit+3;//adding credit hours
        }
        
        
        else if(sub.at(num2)=="CS112")
        {
           
            credit=credit+3;//adding credit hours
        }
        
        
        else if(sub.at(num2)=="CS131") 
        {
            
            credit=credit+3;//adding credit hours
            
        }
        
        else if(sub.at(num2)=="CE121L")
        {
            
            credit=credit+1;//adding credit hours
        }
        
        else if (sub.at(num2)=="CS112L")
        {
         
            credit=credit+1;//adding credit hours
        }
        else
        cout<<"else wala loop ";
        
       
        
        }
    }
        virtual void display()
        {
            cout<<"Your total credit hours are "<<endl<<credit<<endl;
        }
    
        
        
    
};