class add:public course
{
    public:
    void addcourse()
    {
        fstream filee;
        filee.open("CMS.csv",ios::out|ios::app);//using file handling
        cout<<"Enter the name of the course you want to add "<<endl<<endl;//using file handling
       
        
            
        for(;;)
        {
        cin>>course_name;
        filee<<course_name<<endl;
        
        sub.push_back(course_name);//pushing back into vectors
       
        cout<<"Adding courses "<<endl<<endl;
        cout<<"If you want to  add more courses (Press Y or y ) otherwise press N or n "<<endl;
        cin>>addcoursess;
        
        if(addcoursess=='Y'|| addcoursess=='y')
        {
            
            sub.push_back(course_name);
            filee<<course_name<<endl;
            filee.close();//closing filee
        
        }
        
        
        else if(addcoursess=='N'||addcoursess=='n')
        {
       filee.close();
        break;
        }
        else {
            cout<<"wrong choice please try again by entering the correct values "<<endl;//exception handling
            exit(0);
        }
        }  
       
    }
        virtual void display()//polymorphism
        {
        
            for(int k=0;k<sub.size();k++)
        {
            
            cout<<k<<"  "<<sub.at(k)<<endl;
        }
        }
        

    
};