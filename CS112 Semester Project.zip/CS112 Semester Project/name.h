class Name
{
    private:
    string name;
    double reg;
    public:
    Name()
    {
        name="\0";
        reg=0;
    }
    //  OPERATOR OVERLOADING
    friend ostream &operator<<(ostream &out,const Name &n)//friend function
    {
        out<<"Your name is "<<n.name<<"     "<<endl;//displaying name
        out<<"your reg number is"<<n.reg<<endl;//displaying regnumber
        return out;
    }
    friend istream &operator>>(istream &input, Name &n)
    {
        cout<<"Enter your name and reg number ";
        input>>n.name>>n.reg;// entering name and registration number

        return input;//returning output
        
    }
    
};