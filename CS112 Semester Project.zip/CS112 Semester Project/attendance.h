class Attendance
{
    private:
    int week_atten;
    int day_atten;
   
    char attendance_p;
    vector <int> week_a;
    vector<int> day_a;
    vector<char> att;
    char add_a;
   
    public:
    Attendance()// using constructors
    {
    add_a='A';
    attendance_p=0;
    week_atten=0;
    day_atten=0;

    }
    void upload_attendance()
    {
        for(;;)
        {
        cout<<"Which week of attendance you want to upload ";
        cin>>week_atten;
        week_a.push_back(week_atten);//pushing back in vector array
        cout<<"Which day of attendance you want to upload  ";
        cin>>day_atten;
        day_a.push_back(day_atten);//pushing back in vector array
        cout<<"Enter P present of A of Absent ";
        cin>>attendance_p;
        att.push_back(attendance_p);//pushing back in vector array
        cout<<"Do you want to add more attendance (if yes press Y) ";
        cin>>add_a;
        
        if(add_a=='Y'|| add_a=='y')
        {
            continue;
        }
        else 
        break;

        }
    }
        void displayAttendance()//displaying function
        {
            
            cout<<"Weeks";
            for(int i=0;i<week_a.size();i++)
            {
                
                cout<<"     "<<week_a.at(i);//displaying
            
            }
            cout<<endl<<endl<<endl;
            cout<<"Day  ";
                for(int j=0;j<day_a.size();j++)
            {
                
                cout<<"     "<<day_a.at(j);//displaying
            }
            cout<<endl<<endl<<endl;
            cout<<"(P/A)";//displaying
            for(int i=0;i<att.size();i++)
            {
                
                cout<<"     "<<att.at(i);//displaying
            }
            cout<<endl<<endl;
            
            
            
        }
        
    
};
