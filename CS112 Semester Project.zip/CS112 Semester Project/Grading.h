template<class X>//template library
class Grading
{
    vector<int> assignments;//declaring vector array for dynamic array
    vector<int> quizzes;//declaring vector array for dynamic array
    X q,quizz[100],assignmentt[100],aa=0,assignmentaveragee=0,assignmentaverage=0,quizaverage=0,quizaveragee=0;//Template function
    X qn;//Template function
    public:
    Grading()// using constructors
    {
        q=0;
        for(int i=0;i<10;i++)
     {
        quizz[i]=0;//clearing arrays
    }
      for(int i=0;i<10;i++)
     {
        assignmentt[i]=0;//clearing arrays
    }
    aa=0;
    assignmentaveragee=0;// declaring
    assignmentaverage=0;
    quizaverage=0;
    quizaveragee=0;

    }
    void quiz()
    {
        // fstream file;
        cout<<"How many quizzes you want to quizzes you want to enter the marks off ";
        cin>>q;
        for(int i=0;i<q;i++)
        {
            cout<<"Enter the marks of quiz "<<i+1<<endl;
            cin>>quizz[i];//Entering quizzes marks
            
        }
        
    }
    void displayquizresult()
    {
        cout<<"Your marks in all quizzes are "<<endl;
        for(int i=0;i<q;i++)
        {
            cout<<"Quiz "<<i+1<<"  "<<quizz[i]<<endl;
        }
         for(int j=0;j<q;j++)
        {
            quizaveragee=quizaveragee+quizz[j];
        }
        quizaverage=quizaveragee/q;
        cout<<"Your average of quizes is  =  "<<quizaverage<<endl;//calculating average of quizzes
    }
    void Assignment()
    {
        
        cout<<"How many assignments you want to assignments you want to enter the marks off ";
        cin>>aa;
        for(int i=0;i<aa;i++)
        {
            cout<<"Enter the marks assignment "<<i+1<<endl;
            cin>>assignmentt[i];
            
        }

       
        
    }
    void displayassignmentresult()
    {
        cout<<"Your marks in all assignments are "<<endl;

        for(int i=0;i<aa;i++)
        {
            cout<<"Assignment     "<<i+1<<"  "<<assignmentt[i]<<endl;
        }
        for(int j=0;j<aa;j++)
        {
            assignmentaveragee=assignmentaveragee+assignmentt[j];
        }
        assignmentaverage=assignmentaveragee/aa;
        cout<<"Your average of assignments is  =  "<<assignmentaverage<<endl;
        if(assignmentaverage < 0){
            cout<<"wrong values kindly enter correct values of the assignments "<<endl;//displaying average of assignments
            exit(0);
        }
        else{}
        
    }


    
};