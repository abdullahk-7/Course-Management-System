vector<string> sub;
class course//Our main class
{
    
    private:
    
    string name;//Private members
    int reg_num;//Private members
    int num;//Private members
    char ch;//Private members
    string i;//Private members
    
    public:
    
    
    string course_name;//Public members which are accessed by child class
    char addcoursess;//Public members which are accessed by child class
    char displayaddedcourses;//Public members which are accessed by child class
    
    
    void info()//Public function from which we are entering our data
    {
       
        
        fstream file;
        file.open("CMS.csv",ios::out|ios::app);
        cout<<"Enter courses which you have opted from these courses (Enter Course name)"<<endl;
        cout<<"1 HM102 = 3 credit hours "<<endl<<"2 ES111 = 3 credit hours  "<<endl<<"3 CE121 = 3 credit hours  "<<endl;//Our courses
        cout<<"4 CS112 = 3 credit hours "<<endl<<"5 CS131 = 3 credit hours "<<endl<<"6 CE121L = 1 credit hours "<<endl;//Our courses
        cout<<"7 CS112L =1 credit hours "<<endl;//Our available courses
    
        
        
        cout<<"Enter the Name of subjects "<<endl; //Entering the name of the subjects;
        
        for(;;)
        {
            
            
            cin>>i;//Entering the available courses
            sub.push_back(i);//Pushing back in vector
            file<<i<<endl;
            
            cout<<"Press Y or y if you   want to add more subjects "<<endl;//options
            cin>>ch;//options
            if(ch=='Y'||ch=='y')
            {
                 continue;
                
            }
            else if(ch=='N'||ch=='n')
            {
                break;
                file.close();
            }
            else
            {
                break;
                // throw("You entered wrong input ");
            }
           
            } 
            }

    virtual void display()
    {
        //cout<<"Displaying "<<endl;
        for(int num1=0;num1<sub.size();num1++)
        {
            cout<<num1<<"   "<<sub.at(num1)<<endl;
        }
    }


};
