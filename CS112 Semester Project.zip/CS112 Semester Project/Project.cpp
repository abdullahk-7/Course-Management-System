//<-----------------------CMS--------------------->
#include<iostream>//input output library
#include<vector>// used for vector array
#include<unistd.h>// The <unistd. h> header defines miscellaneous symbolic constants and types, and declares miscellaneous functions.
#include<fstream>//used to enter data in file
#include<sstream>// used to covert string into integer using stoi function
#include<stdio.h>//This library uses what are called streams to operate with physical devices such as keyboards, printers, terminals or with any other type of files supported by the system.
#include<cstdlib>//his header defines a collection of functions and macros to facilitate efficient, high-performing, standardized C++ code across teams and platforms.
#include<stdexcept>//set of standard exceptions that both the library and programs can use to report common errors.
using namespace std;



#include"courseclass.h"//includes the course header file
#include"name.h"//includes the name header file
#include"add.h"//include the add header file
#include "withdrawal.h"//includes the withdrawal header file
#include"totalcredithour.h"//includes the totalcredithour header file
#include"attendance.h"//includes the attendance header file
#include "Grading.h"//includes the grading header file


 


const double delay=3000000;// Global Declarations of a time constant to use delays





int main()
{
    //CLASSES and OBJECTS
    Name NN[100];// name object further used in operator overloading 
    course c[100],*tc,*wc,*ad;//courses used to display courses objects
    add a[100],aad;// add class used to add courses
    withdrawal w[100],wwc;// withdrawal courses used in withdrawal of courses
    Attendance at[100];//attendance used in attending classes
    Grading<double> g[100];//grading class used in grading
    Totalcredithours t;//total credit hour class used to calculate total credit hour
    tc=&t;//storing address of data in pointer
    wc=&wwc;//storing address of data in pointer
    ad=&aad;//storing address of data in pointer
    int choice;//declarations
    char another_student;//declarations
    int d_panel=0,number_ofstd;//declarations
    vector<int> student;//declarations of vector
    char menuoption;//declarations
    string reg_num,name;//declarations
    int i=0;//declarations
    cout<<"              🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥"<<endl;//shashkay
    cout<<"                 Welcome to course management system "<<endl;
    cout<<"              🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥"<<endl<<endl<<endl<<endl;//shahkay
    for(;;)//infinite loop used to enter data of any amount of data used wants to enter
    {
        
        cin>>NN[i];//operator overloading used to enter name of the object
        
    
    cout<<"                 Enterting for student  "<<i+1<<endl<<endl<<endl;
    
    //MENU OPTIONS
    
    cout<<endl;
    cout<<"                 Please select your desired choice (Enter Number)"<<endl; //MENU OPTIONS
    cout<<"                 To Select any courses Press 1 "<<endl; //MENU OPTIONS
    //info
    cout<<"                 To Add more courses press 2 "<<endl; //MENU OPTIONS
    //add course
    cout<<"                 To withdrawal any course press 3 "<<endl; //MENU OPTIONS
    //withdrawalcourse
    
    //displaywithdrawalcourse
    cout<<"                 To upload your attendance press 4 "<<endl; //MENU OPTIONS
    //upload attendance
    
    //display attendance
    cout<<"                 To upload your quiz marks press 5"<<endl; //MENU OPTIONS
    //quizmarks
   
    //displayquizresult
    cout<<"                 To upload your assignment marks press 6"<<endl; //MENU OPTIONS
    //assignment marks
    
    //displayassignment marks
    cout<<"                 Press 0 to exit "<<endl; //MENU OPTIONS
    cin>>choice;
    if(choice==1)//asking for choice
    {
        c[i].info();//calling class course and object
        
    }
    else if (choice==2)
    {
        a[i].addcourse();//calling class add and object of class
        
    }
    else if(choice==3)
    {
        w[i].withdrawalcourse();//calling class withdrawal and object of class
        
    }
    
     else if(choice==4)
    {
        at[i].upload_attendance(); //calling class attendance  and object of class
        
    }
    
     else if(choice==5)
    {
        g[i].quiz();//calling class grading and object of class
        
        
    }
    
     else if(choice==6)
    {
        g[i].Assignment();//calling class grading and object of class
        
    }
  
    else if(choice==0)
    {
        cout<<"You successfully exited "<<endl;//exiting
        break;
    }
    else{
        cout<<"wrong input exiting ";
        exit;//exiting exception handling
    }
    
    cout<<"                 Do you want to add something else or Do you want to go in Menu again (press Y for yes and n for no)"<<endl<<endl<<endl;
    cin>>another_student;
    if(another_student=='Y'||another_student=='y')//asking choice
    {
       
        continue;
    }
    else if(another_student=='N'||another_student=='n')//asking for choice
    {
    
    
    i++;
    for(int j=0;j<i;j++)// running till the the value of i
    {
    cout<<"             🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥"<<endl;
    cout<<"                 Displaying Panel "<<endl;
    cout<<"             🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥🫥"<<endl<<endl<<endl;
    cout<<"                 To display your courses press 1 "<<endl;
    cout<<"                 To display your added courses press 2 "<<endl;
    cout<<"                 To display your withdrawal courses press 3 "<<endl;
    
    cout<<"                 To check your attendance press 4 "<<endl;
    cout<<"                 To view your quiz marks press 5 "<<endl;
    cout<<"                 To view your assignment marks press 6 "<<endl;
    cout<<"                 To view your total credit hours press 7 "<<endl;
    
    cin>>d_panel;
    if(d_panel==1)
    {
        cout<<"Displaying  (5 seconds delay) "<<endl;//displaying using virual function polymorphism
         usleep(delay);
        
        c[j].display();
    }
     else if(d_panel==3)
    {
        cout<<"Displaying  (5 seconds delay) "<<endl;//displaying using virual function polymorphism
         usleep(delay);//delaying function just to make it more realistic
        wc->display();
        
    }
    else if(d_panel==2)
    {
        cout<<"Displaying  (5 seconds delay) "<<endl;//displaying using virual function polymorphism
         usleep(delay);//delaying function just to make it more realistic
        ad->display();
    }
 else if(d_panel==4)
    {
        cout<<"Displaying attendance (5 seconds delay) "<<endl;//displaying using virual function polymorphism
        usleep(delay);//delaying function just to make it more realistic
        at[j].displayAttendance();
        
    }
    else if(d_panel==5)
    {
        cout<<"Displaying  (5 seconds delay) "<<endl;//displaying using virual function polymorphism
         usleep(delay);//delaying function just to make it more realistic
        g[j].displayquizresult();
        
    }
   else if(d_panel==6)
    {
        cout<<"Displaying  (5 seconds delay) "<<endl;//displaying using virual function polymorphism
         usleep(delay);//delaying function just to make it more realistic
        g[j].displayassignmentresult();
       
    }
    else if(d_panel==7)
    {
        t.totalcredithrs();
        cout<<"Displaying  (5 seconds delay) "<<endl;//displaying using virual function polymorphism
         usleep(delay);//delaying function just to make it more realistic
         tc->display();
        //cout<<"Your total credit hours are "<<t.totalcredithrs()<<endl;
    }
    else
    {
        cout<<"Wrong input "<<endl<<"Exiting ";//Exception handling
    break;
    }
    
    
    }
    cout<<"Do you want to add students again (Press Y or y )"<<endl;
    cin>>menuoption;
    if(menuoption=='Y'||menuoption=='y')
    {
        i++;
        continue;
    }
    
    else
    {
    i++;
    cout<<"Thank You for using CMS ";
    break;
    }
    }
    
    }       
    return 0;

}
